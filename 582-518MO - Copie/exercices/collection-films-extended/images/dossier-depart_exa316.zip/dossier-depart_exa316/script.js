/* Le MODEL Vue en JS */
