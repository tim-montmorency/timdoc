const app = Vue.createApp({
  data() {
    return {
      name: "-",
      equipmentsArr: [
        {
          wearing: false,
          defense: 2,
          weight: 5,
          image: 'https://ex.smnarnold.com/vue/chevalier/casque.png'
        },
        {
          wearing: false,
          defense: 4,
          weight: 15,
          image: 'https://ex.smnarnold.com/vue/chevalier/plastron.png'
        },
        {
          wearing: false,
          defense: 1,
          weight: 10,
          image: 'https://ex.smnarnold.com/vue/chevalier/cuissard.png'
        },
      ],
    }
  }
});