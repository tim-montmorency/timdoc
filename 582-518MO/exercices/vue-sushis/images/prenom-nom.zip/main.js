const app = Vue.createApp({
  data() {
    return {
      sushisArr: [
        {
          name: 'Maguro',
          price: '7.99',
          mx: 2,
          nbr: 0,
          image: 'https://ex.smnarnold.com/vue/sushis/1.png'
        },
        {
          name: 'Bermude',
          price: '8.99',
          mx: 3,
          nbr: 0,
          image: 'https://ex.smnarnold.com/vue/sushis/2.png'
        },
        {
          name: 'Syake',
          price: '6.99',
          mx: 2,
          nbr: 0,
          image: 'https://ex.smnarnold.com/vue/sushis/3.png'
        },
        {
          name: 'Diablo',
          price: '6.66',
          mx: 5,
          nbr: 0,
          image: 'https://ex.smnarnold.com/vue/sushis/4.png'
        },
        {
          name: 'Izumidai',
          price: '8.50',
          mx: 2,
          nbr: 0,
          image: 'https://ex.smnarnold.com/vue/sushis/5.png'
        },
        {
          name: 'Kamikaze',
          price: '5.79',
          nbr: 0,
          mx: 5,
          image: 'https://ex.smnarnold.com/vue/sushis/6.png'
        }
      ]
    }
  },
});