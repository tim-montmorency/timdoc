const espaceTravail = document.querySelector(".espace-de-travail");

function bindClickEventOnIngredients() {

  console.log("Éxécution de la fonction bindClickEventOnIngredients");

  let ingredientsArr = document.querySelectorAll(".ingredient");

  ingredientsArr.forEach(ingredient => {

    ingredient.style.cursor = "pointer";

    ingredient.addEventListener('click', () => {

      ingredient.classList.add("pret");

      if (document.querySelectorAll(".pret").length == 5) {
        let hamburgerComplet = document.createElement("div");
        hamburgerComplet.classList.add("burger", "blt");

        espaceTravail.appendChild(hamburgerComplet);
        espaceTravail.style.overflow = "visible";

      }

    });

  });

}
