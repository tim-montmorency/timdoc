const prix = [
  {
    nom: 'Voyage',
    couleur: 'yellow' //0 à 89 
  },
  {
    nom: 'Argent',
    couleur: 'green' //90 à 179
  },
  {
    nom: 'Escapade',
    couleur: 'blue' //180 à 269   
  },
  {
    nom: 'Voiture',
    couleur: 'red'  //270 à 359 
  }
];

const panneauTxt = document.querySelector('.panneau .texte');
const panneau = document.querySelector('.panneau');

function pige() {
  return Math.floor(Math.random() * 360);
}

function affichagePrix(degres) {
  let nom;
  let couleur;
  let i;
  if (degres <= 90) {
    i = 0;
  } else if (degres <= 180) {
    i = 1;
  } else if (degres <= 270) {
    i = 2;
  } else {
    i = 3;
  }
  panneauTxt.innerText = prix[i].nom;
  panneau.classList.add(prix[i].couleur);
}

function reinitialiserPanneau() {
  panneauTxt.innerText = "";
  panneau.classList.remove("yellow","red","blue","green");
}
